import { HelpCircle, Plus } from 'lucide-react';
import { useState } from 'react';

const faqItems = [
    {
        question: 'Apakah kelas ini cocok untuk fresh graduate?',
        answer:
            'Ya. Semakin cepat memahami dunia kerja, semakin cepat karier Anda berkembang. Modul untuk First Jobbers dirancang khusus untuk yang baru memulai perjalanan karier.',
    },
    {
        question: 'Apakah kelas ini cocok untuk karyawan berpengalaman?',
        answer:
            'Ya. Cocok untuk profesional yang merasa kariernya mulai stagnan dan ingin naik ke level berikutnya. Paket Managers dirancang khusus untuk akselerasi ke posisi eksekutif.',
    },
    {
        question: 'Apakah pembelajarannya live?',
        answer:
            'Tidak. Kelas dapat diakses online secara fleksibel sesuai waktu Anda. Anda juga mendapatkan akses ke rekaman live session dari batch-batch sebelumnya.',
    },
    {
        question: 'Apakah ada sesi mentoring langsung dengan Coach Shaun?',
        answer:
            'Untuk paket Managers, terdapat fitur Review PR Personal langsung oleh Shaun Dju. Materi juga disusun untuk dipelajari secara mandiri dan sistematis.',
    },
    {
        question: 'Berapa lama akses kelas diberikan?',
        answer:
            'Sesuai kebijakan akses yang berlaku saat pembelian. Pastikan Anda membaca ketentuan sebelum melakukan pembelian.',
    },
    {
        question: 'Apakah materinya hanya teori?',
        answer:
            'Tidak. Setiap modul dilengkapi tugas praktik (PR) yang dapat langsung diterapkan di dunia kerja. Setelah selesai satu BAB, ada assignment yang bisa langsung Anda coba di kantor.',
    },
    {
        question: 'Apakah kelas ini menjamin promosi atau kenaikan gaji?',
        answer:
            'Tidak. Namun Anda akan mempelajari kemampuan dan strategi yang digunakan para top performer untuk berkembang lebih cepat dalam karier. Hasilnya bergantung pada usaha dan konsistensi Anda.',
    },
    {
        question: 'Apa perbedaan paket First Jobbers dan Managers?',
        answer:
            'Paket First Jobbers terdiri dari 4 modul, cocok untuk yang baru masuk dunia kerja dan ingin 2x salary dalam 3 tahun. Paket Managers terdiri dari 5 modul dan dilengkapi Review PR Personal langsung oleh Shaun, dirancang untuk mencapai posisi eksekutif dan gaji 3 digit.',
    },
];

export default function Faq() {
    const [openIndex, setOpenIndex] = useState<number | null>(0);

    const toggle = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

    return (
        <section
            id="faq"
            className="relative bg-[#0C1F13] py-20 sm:py-28"
        >
            <div className="relative mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
                <div className="text-center">
                    <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.18em] text-white/70">
                        <HelpCircle className="h-3.5 w-3.5 text-[#4ADE80]" />
                        FAQ
                    </span>
                    <h2 className="mt-6 text-3xl font-extrabold leading-tight tracking-tight text-white sm:text-4xl lg:text-5xl">
                        Pertanyaan yang{' '}
                        <span className="text-[#4ADE80]">
                            sering ditanyakan
                        </span>
                    </h2>
                    <p className="mt-4 text-base text-white/60 sm:text-lg">
                        Belum nemu jawabannya? Hubungi kami langsung.
                    </p>
                </div>

                <div className="mt-12 space-y-3 sm:mt-14">
                    {faqItems.map((item, index) => {
                        const isOpen = openIndex === index;
                        return (
                            <div
                                key={index}
                                className={`overflow-hidden rounded-2xl border transition-all duration-300 ${
                                    isOpen
                                        ? 'border-[#4ADE80]/35 bg-white/[0.05]'
                                        : 'border-white/10 bg-white/[0.02] hover:border-white/20'
                                }`}
                            >
                                <button
                                    id={`faq-item-${index}`}
                                    onClick={() => toggle(index)}
                                    className="flex w-full items-center justify-between gap-4 px-5 py-5 text-left sm:px-7"
                                >
                                    <span
                                        className={`text-sm font-bold sm:text-base ${
                                            isOpen
                                                ? 'text-[#4ADE80]'
                                                : 'text-white'
                                        }`}
                                    >
                                        {item.question}
                                    </span>
                                    <span
                                        className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full transition-all duration-300 ${
                                            isOpen
                                                ? 'rotate-45 bg-[#4ADE80] text-[#0C1F13]'
                                                : 'bg-white/10 text-white/70'
                                        }`}
                                    >
                                        <Plus className="h-4 w-4" />
                                    </span>
                                </button>
                                <div
                                    className={`grid transition-all duration-300 ease-in-out ${
                                        isOpen
                                            ? 'grid-rows-[1fr] opacity-100'
                                            : 'grid-rows-[0fr] opacity-0'
                                    }`}
                                >
                                    <div className="overflow-hidden">
                                        <p className="px-5 pb-6 text-sm leading-relaxed text-white/70 sm:px-7 sm:text-base">
                                            {item.answer}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>

                <div className="mt-12 text-center">
                    <p className="text-sm text-white/60">
                        Masih ada pertanyaan lain?{' '}
                        <a
                            href="#footer"
                            className="font-bold text-[#4ADE80] underline-offset-4 hover:underline"
                        >
                            Hubungi kami sekarang
                        </a>
                    </p>
                </div>
            </div>
        </section>
    );
}
