import AnalyticsController from './AnalyticsController'
import DashboardController from './DashboardController'
import LabsController from './LabsController'
import Settings from './Settings'
const Controllers = {
    AnalyticsController: Object.assign(AnalyticsController, AnalyticsController),
DashboardController: Object.assign(DashboardController, DashboardController),
LabsController: Object.assign(LabsController, LabsController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers