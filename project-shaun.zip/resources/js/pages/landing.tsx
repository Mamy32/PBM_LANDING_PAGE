import { Head } from '@inertiajs/react';

import { useEffect } from 'react';
import { useAnalytics } from '@/hooks/use-analytics';
import { useDwellTime } from '@/hooks/use-dwell-time';
import { useScrollTracking } from '@/hooks/use-scroll-tracking';
import { useSectionTracking } from '@/hooks/use-section-tracking';
import Curriculum from './landing/curriculum';
import Faq from './landing/faq';
import Footer from './landing/footer';
import Hero from './landing/hero';
import Instructor from './landing/instructor';
import MediaFeatures from './landing/media-features';
import Navbar from './landing/navbar';
import PracticalBenefits from './landing/practical-benefits';
import Pricing from './landing/pricing';
import Problem from './landing/problem';
import Solution from './landing/solution';
import SuccessStory from './landing/success-story';
import Testimonials from './landing/testimonials';
import VideoTeaser from './landing/video-teaser';
export default function Landing() {
    const { trackVisit } = useAnalytics();

    // Force light mode on mount, restore on unmount
    useEffect(() => {
        const htmlEl = document.documentElement;
        const wasDark = htmlEl.classList.contains('dark');

        htmlEl.classList.remove('dark');

        return () => {
            if (wasDark) {
                htmlEl.classList.add('dark');
            }
        };
    }, []);

    // Initialize tracking hooks
    useScrollTracking();
    useDwellTime();

    useSectionTracking();

    // Track page visit on mount
    useEffect(() => {
        trackVisit();
    }, [trackVisit]);

    return (
        <>
            <Head>
                <title>
                    Cara Dapet Gaji Ratusan Juta/Bulan Sebelum Umur 30 —
                    Shaundju Academy
                </title>
                <meta
                    name="description"
                    content="Pelajari strategi yang digunakan para top performer untuk mempercepat kenaikan penghasilan. 75+ materi, lifetime access, komunitas privat. Dipercaya 1.000+ professionals."
                />
            </Head>

            <div className="min-h-screen bg-[#0C1F13] text-white antialiased selection:bg-[#4ADE80] selection:text-[#0C1F13]">
                <Navbar />
                <Hero />
                <SuccessStory />
                <Solution />
                <Problem />
                <PracticalBenefits />
                <Testimonials />
                <Instructor />
                <MediaFeatures />
                <Curriculum />
                <Pricing />
                <VideoTeaser />
                <Faq />
                <Footer />
            </div>
        </>
    );
}
